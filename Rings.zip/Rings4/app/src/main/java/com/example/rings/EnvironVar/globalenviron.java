package com.example.rings.EnvironVar;

import com.androidstudy.daraja.Daraja;

public class globalenviron {
    public static String myemail;
    public static String myname;
    public static String accesstoken;
    public static String passkey;
    public static String businessshortcode;
    public static Daraja daraja;
    public static boolean doihaveavailablerings=false;
}
